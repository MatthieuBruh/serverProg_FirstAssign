package com.example.firstAssignment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirstAssignmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
