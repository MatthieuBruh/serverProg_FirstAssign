package com.example.firstAssignment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FirstAssignmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(FirstAssignmentApplication.class, args);
	}

}
